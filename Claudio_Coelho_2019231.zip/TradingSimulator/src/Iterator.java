
//Interface For Iterator Pattern
public interface Iterator {
    boolean hasNext();
    Object next();
}
