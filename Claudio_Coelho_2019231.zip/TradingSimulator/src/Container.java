
// Interface Required For Iterator Design Pattern
public interface Container {
    public Iterator getIterator();
}
